package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.dto.FinanceDto;
import com.example.demo.model.Finance;
import com.example.demo.repository.FinanceRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * FinanceServiceImp
 */
@Service
public class FinanceServiceImp implements FinanceService {

    @Autowired
    private FinanceRepository financeRepository;

    @Autowired

    private ModelMapper modelMapper;

    @Override
    public Finance addFinance(Finance finance) {

        return financeRepository.save(finance);
    }

    @Override
    public List<Finance> getAllFinancess() {

        return financeRepository.findAll();
    }

    @Override
    public Finance getFinanceById(Integer id) {

        return financeRepository.getOne(id);
    }

    @Override
    public void deleteFinanceById(Integer id) {
        financeRepository.deleteById(id);

    }

    @Override
    public List<FinanceDto> convertToDto(List<Finance> finances) {

        List<FinanceDto> financeDtoList = new ArrayList<>();

        for (Finance finance : finances) {

            FinanceDto financeDto = modelMapper.map(finance, FinanceDto.class);

            financeDtoList.add(financeDto);

        }

        return financeDtoList;
    }

    @Override
    public FinanceDto convertToDto(Finance finance) {
        FinanceDto financeDto = modelMapper.map(finance, FinanceDto.class);

        return financeDto;
    }

}
