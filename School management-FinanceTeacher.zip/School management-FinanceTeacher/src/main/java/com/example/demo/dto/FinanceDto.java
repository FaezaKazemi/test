package com.example.demo.dto;

/**
 * FinanceDto
 */
public class FinanceDto {

    private Integer _id;
    private String firstName;
    private String lastName;
    private Integer month;
    private Double salary;

    private Integer teacher_Id;



    public Integer get_id() {
        return _id;
    }
    public void set_id(Integer _id) {
        this._id = _id;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public Integer getMonth() {
        return month;
    }
    public void setMonth(Integer month) {
        this.month = month;
    }
    public Double getSalary() {
        return salary;
    }
    public void setSalary(Double salary) {
        this.salary = salary;
    }
    public Integer getTeacher_Id() {
        return teacher_Id;
    }
    public void setTeacher_Id(Integer teacher_Id) {
        this.teacher_Id = teacher_Id;
    }
    

    
}