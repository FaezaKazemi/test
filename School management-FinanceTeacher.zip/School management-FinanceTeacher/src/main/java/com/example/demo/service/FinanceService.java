package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.FinanceDto;
import com.example.demo.model.Finance;

/**
 * FinanceService
 */
public interface FinanceService {

    Finance addFinance(Finance finance);

    List<Finance> getAllFinancess();

    Finance getFinanceById(Integer id);

    void deleteFinanceById(Integer id);

    List<FinanceDto> convertToDto(List<Finance> finances);

    FinanceDto convertToDto(Finance finance);

}