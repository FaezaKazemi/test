package com.example.demo.Controller;

import com.example.demo.dto.TeacherDto;
import com.example.demo.model.Teacher;
import com.example.demo.service.FinanceService;
import com.example.demo.service.TeacherService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * TeacherController
 */
@RestController
public class TeacherController {

    @Autowired

    private TeacherService teacherService;

    @Autowired
    private FinanceService financeService;

    @GetMapping("/teacher/all")

    public ResponseEntity<List<TeacherDto>> getTeachers() {

        List<Teacher> teachers = teacherService.getAllTeachers();

        List<TeacherDto> teacherDtoList = teacherService.convertToDto(teachers);

        return new ResponseEntity<>(teacherDtoList, HttpStatus.OK);
    }

    @PostMapping(value = "/teacher/add")

    public ResponseEntity<TeacherDto> addTeacher(@RequestBody Teacher teacher) {

        teacher.setFinance(financeService.getFinanceById(21));

        Teacher savedTeacher = teacherService.saveTeacher(teacher);

        TeacherDto teacherDto = teacherService.convertToDto(savedTeacher);

        return new ResponseEntity<>(teacherDto, HttpStatus.CREATED);

    }

}
