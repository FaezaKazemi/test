package com.example.demo.service;


import java.util.ArrayList;
import java.util.List;

import com.example.demo.dto.TeacherDto;
import com.example.demo.model.Teacher;
import com.example.demo.repository.TeacherRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * TeacherServiceImp
 */
@Service
public class TeacherServiceImp implements TeacherService{

    @Autowired

   private TeacherRepository teacherRepository;

   @Autowired

   private ModelMapper modelMapper;

  

  
    @Override
    public Teacher saveTeacher(Teacher teacher) {
      
        return teacherRepository.save(teacher) ;
    }

    @Override
    public List<Teacher> getAllTeachers() {
        
        return teacherRepository.findAll();
    }

    @Override
    public Teacher getById(Integer id) {
        
        return teacherRepository.getOne(id);
    }

    @Override
    public List<TeacherDto> convertToDto(List<Teacher> teachers) {

        List<TeacherDto> teacherDtoList = new ArrayList<>();

        for(Teacher teacher : teachers){
            TeacherDto teacherDto = modelMapper.map(teacher, TeacherDto.class);
            teacherDtoList.add(teacherDto);
        }
       
        return teacherDtoList;
    }

    @Override
    public TeacherDto convertToDto(Teacher teacher) {
        TeacherDto teacherDto = modelMapper.map(teacher, TeacherDto.class);

        return teacherDto;
    }

   
        
   

   

   

    
}