package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Finance
 */
@Entity
@Table(name = "financess")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer" , "handler"})
public class Finance {
   
    private Integer _id;
    private String firstName;
    private String lastName;
    private Integer month;
    private Double salary;


    private Teacher teacher;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public Finance(){

    };

    public Finance(Integer _id, String firstName, String lastName, Integer month, Double salary) {
        this._id = _id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.month = month;
        this.salary = salary;
    }

    @OneToOne
    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
}