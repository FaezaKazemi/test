package com.example.demo.dto;

/**
 * TeacherDto
 */
public class TeacherDto {

    private Integer _id;
    private String firstName;
    private String lastName;
    private String gender;
    private Double salary;
    private String time;

    private Integer finance_Id;

    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getFinance_Id() {
        return finance_Id;
    }

    public void setFinance_Id(Integer finance_Id) {
        this.finance_Id = finance_Id;
    }

}
