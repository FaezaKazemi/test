package com.example.demo.Controller;

import java.util.List;

import com.example.demo.dto.FinanceDto;
import com.example.demo.model.Finance;

import com.example.demo.service.FinanceService;
import com.example.demo.service.TeacherService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * FinanceContoller
 */

@RestController
public class FinanceContoller {
    @Autowired
    private FinanceService financeService;

    @Autowired

    private TeacherService teacherService;

   

    @GetMapping("/financeTeacher/all")

    public ResponseEntity<List<FinanceDto>> getFinances() {

        List<Finance> finances = financeService.getAllFinancess();

        List<FinanceDto> financeDtoList = financeService.convertToDto(finances);

        return new ResponseEntity<>(financeDtoList, HttpStatus.OK);
    }

    @PostMapping("/finance/add")
    public ResponseEntity<FinanceDto> addFinance(@RequestBody Finance finance) {
        finance.setTeacher(teacherService.getById(16));
       

        Finance savedFinane = financeService.addFinance(finance);

        FinanceDto financeDto = financeService.convertToDto(savedFinane);

        return new ResponseEntity<>(financeDto, HttpStatus.CREATED);
    }

    @GetMapping("/finance/{id}")

    public ResponseEntity<Finance> getOneFinance(@PathVariable("id") Integer id) {

        Finance finance = financeService.getFinanceById(id);

        return new ResponseEntity<>(finance, HttpStatus.OK);
    }

    @PutMapping("finance/update")
    public ResponseEntity<Finance> updateFinance(@RequestBody Finance finance) {

        

        Finance savedFinane = financeService.addFinance(finance);

        return new ResponseEntity<>(savedFinane, HttpStatus.OK);
    }

    @DeleteMapping("finance/{id}/delete")
    public ResponseEntity<String> deleteFinance(@PathVariable("id") Integer id) {

        financeService.deleteFinanceById(id);

        return new ResponseEntity<>("Successfully delete!", HttpStatus.OK);

    }

}
