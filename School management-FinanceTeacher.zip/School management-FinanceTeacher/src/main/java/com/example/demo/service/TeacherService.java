package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.TeacherDto;
import com.example.demo.model.Teacher;

/**
 * TeacherService
 */
public interface TeacherService {

    Teacher saveTeacher(Teacher teacher);

    List<Teacher> getAllTeachers();

    Teacher getById(Integer id);

    List<TeacherDto> convertToDto(List<Teacher> teachers);

    TeacherDto convertToDto(Teacher teacher);

    
   

}
